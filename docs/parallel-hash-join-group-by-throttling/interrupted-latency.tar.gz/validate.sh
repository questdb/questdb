#!/usr/bin/env bash
set -euo pipefail
cd /home/puzpuzpuz/projects/questdb
shared_output=/tmp/questdb-shared-throttle
git diff HEAD -- core benchmarks > "$shared_output/source.patch"
shared_test_suites=$(python3 - <<'PY'
import csv
with open('docs/parallel-hash-join-group-by-semantics/regressions.csv') as source:
 print(','.join(row['suite'].rsplit('.', 1)[-1] for row in csv.DictReader(source)))
PY
)
printf 'mvn -pl core test -P build-rust-library,qdbr-release -Dtest=%q\n' "$shared_test_suites" > "$shared_output/commands.txt"
mvn -pl core test -P build-rust-library,qdbr-release -Dtest="$shared_test_suites" > "$shared_output/regressions.txt" 2>&1
python3 - <<'PY'
import csv
from pathlib import Path
import xml.etree.ElementTree as ET
with open('docs/parallel-hash-join-group-by-semantics/regressions.csv') as source:
 suites=[r['suite'] for r in csv.DictReader(source)]
suites+=['io.questdb.test.cairo.map.MapTest','io.questdb.test.cairo.map.UnorderedVarcharMapTest']
with open('/tmp/questdb-shared-throttle/regressions.csv','w') as out:
 w=csv.writer(out,lineterminator='\n');w.writerow(['suite','tests','failures','errors','skipped','seconds'])
 for suite in suites:
  root=ET.parse(Path('core/target/surefire-reports')/('TEST-'+suite+'.xml')).getroot()
  assert root.attrib['failures']=='0' and root.attrib['errors']=='0',suite
  w.writerow([suite]+[root.attrib[k] for k in ('tests','failures','errors','skipped','time')])
PY
printf '%s\n' 'mvn -pl benchmarks -am package -P build-rust-library,qdbr-release -DskipTests -Dmaven.test.skip=true' >> "$shared_output/commands.txt"
mvn -pl benchmarks -am package -P build-rust-library,qdbr-release -DskipTests -Dmaven.test.skip=true > "$shared_output/build.txt" 2>&1
cp benchmarks/target/benchmarks.jar "$shared_output/candidate.jar"
sha256sum "$shared_output/candidate.jar" "$shared_output/source.patch" > "$shared_output/artifacts.sha256"
shared_pattern="^($(paste -sd '|' benchmarks/parallel-hash-join-group-by-recovery-cases.txt))$"
CASE_PATTERN="$shared_pattern" BENCHMARK_JAR="$shared_output/candidate.jar" BENCHMARK_REVISION=4ae9efb0f0+shared-throttle BREAKER_MODE=active bash benchmarks/parallel-hash-join-group-by-v1.sh "$shared_output/candidate" > "$shared_output/candidate.txt" 2>&1
set +e
python3 benchmarks/compare-hash-join-group-by-recovery.py docs/parallel-hash-join-group-by-recovery/reference "$shared_output/candidate" "$shared_output/comparison.csv" > "$shared_output/comparison.txt" 2>&1
shared_comparison_status=$?
set -e
printf '%s\n' "$shared_comparison_status" > "$shared_output/comparison.status"
cmp benchmarks/target/benchmarks.jar "$shared_output/candidate.jar"
bash benchmarks/parallel-hash-join-group-by-allocation.sh "$shared_output/allocation" > "$shared_output/allocation.txt" 2>&1
printf 'Validation completed; performance comparison exit status: %s\n' "$shared_comparison_status"

#!/usr/bin/env bash
set -euo pipefail
cd /home/puzpuzpuz/projects/questdb
clock_suite_flags=(-ea -Dfile.encoding=UTF-8 -XX:+UseParallelGC --sun-misc-unsafe-memory-access=allow
  --enable-native-access=ALL-UNNAMED --add-opens=java.base/java.lang=ALL-UNNAMED
  --add-opens=java.base/java.lang.reflect=ALL-UNNAMED --add-opens=java.base/java.nio=ALL-UNNAMED
  --add-opens=java.base/java.time.zone=ALL-UNNAMED --add-exports=java.base/jdk.internal.vm=ALL-UNNAMED)
clock_suite_junit=/home/puzpuzpuz/.m2/repository/junit/junit/4.13.2/junit-4.13.2.jar
clock_suite_hamcrest=/home/puzpuzpuz/.m2/repository/org/hamcrest/hamcrest-core/1.3/hamcrest-core-1.3.jar
java "${clock_suite_flags[@]}" -cp "core/target/test-classes:/tmp/questdb-task9f/before.jar:$clock_suite_junit:$clock_suite_hamcrest" /tmp/questdb-task9f/ClockRegressionCheck.java true > /tmp/questdb-task9f/clock-regression-red.txt 2>&1
java "${clock_suite_flags[@]}" -cp "core/target/test-classes:/tmp/questdb-task9f/final.jar:$clock_suite_junit:$clock_suite_hamcrest" /tmp/questdb-task9f/ClockRegressionCheck.java false > /tmp/questdb-task9f/clock-regression-green.txt 2>&1

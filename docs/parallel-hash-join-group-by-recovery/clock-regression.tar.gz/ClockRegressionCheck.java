import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
public class ClockRegressionCheck {
    public static void main(String[] args) throws Exception {
        Result result = new JUnitCore().run(Request.method(
            Class.forName("io.questdb.test.griffin.AsyncHashJoinGroupByTest"),
            "testNetworkProbeChecksArePeriodicAndBounded"));
        result.getFailures().forEach(f -> System.out.println(f.getTrace()));
        if (Boolean.parseBoolean(args[0])) {
            if (result.getFailureCount() != 1 || !result.getFailures().getFirst().getMessage().contains("clock reads must be throttled")) {
                throw new AssertionError("expected the prechange engine's per-row clock regression");
            }
            System.out.println("PASS: scoped census rejects the prechange engine's per-row clock reads");
        } else {
            if (!result.wasSuccessful()) throw new AssertionError("candidate census failed");
            System.out.println("PASS: scoped census accepts the candidate");
        }
    }
}
